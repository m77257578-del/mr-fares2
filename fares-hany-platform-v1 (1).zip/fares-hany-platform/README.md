# Mr Fares Hany — Full-Stack English Learning Platform

نسخة برمجية مخصصة للعمل من VS Code، وليست مجرد HTML.

## التقنية
- Node.js 20+
- Express
- SQLite عبر better-sqlite3
- JWT authentication
- bcryptjs لتشفير كلمات المرور
- Multer لرفع الملفات
- Vanilla HTML/CSS/JS في الواجهة

## التشغيل على جهازك
```bash
npm install
copy .env.example .env
npm run seed
npm start
```

ثم افتح:
- الموقع: http://localhost:3000
- لوحة المدرس: http://localhost:3000/admin.html

الحساب التجريبي يتم إنشاؤه من `.env`، والافتراضي في المشروع:
- Email: `admin@fareshany.com`
- Password: `ChangeMe123!`

غيّر كلمة المرور قبل أي استخدام فعلي.

## أهم وظائف الـBackend
- تسجيل الطلاب ودخولهم.
- صلاحية `admin` للمدرس.
- إدارة الكورسات.
- إنشاء دروس ونشر فيديوهات ومذكرات وواجبات.
- إنشاء أكواد اشتراك مرتبطة بكورس ومدة.
- تفعيل الكود وإنشاء Enrollment للطالب.
- إنشاء امتحان MCQ وتصحيح تلقائي.
- تسليم واجبات مع رفع ملفات.
- تصحيح الواجبات يدويًا من لوحة المدرس.
- إعلانات للطلاب.
- إحصائيات لوحة الإدارة.
- رابط WhatsApp دائم للمدرس على الرقم الموجود في `.env`.
- مترجم داخلي مع قاموس أساسي، ويمكن ربط API ترجمة حقيقي عن طريق `TRANSLATE_URL`.

## تحويله إلى نظام Online حقيقي
النسخة دي Full-Stack حقيقية وتعمل محليًا بقاعدة SQLite. للنشر على الإنترنت، يمكن تشغيل نفس Node.js على Render/Railway/VPS وربط قاعدة PostgreSQL أو SQLite persistent volume، وربط تخزين ملفات وفيديو آمن. كما يفضل إضافة HTTPS، rate limiting، CSRF protection، validation، refresh tokens، وإدارة نسخ احتياطية.

## أمان مهم
لا تضع أسرار الدفع أو مفاتيح API في JavaScript الخاص بالمتصفح. كل الأسرار تكون في `.env` وعلى الخادم فقط.
