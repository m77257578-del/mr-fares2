require('dotenv').config();
const express = require('express');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const db = require('./db');
const { requireAuth, requireAdmin } = require('./middleware/auth');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const uploadDir = path.join(__dirname, process.env.UPLOAD_DIR || 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });

app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(uploadDir));
app.use(express.static(path.join(__dirname, 'public')));

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_');
    cb(null, `${Date.now()}-${safe}`);
  }
});
const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 } });

function signToken(user) {
  return jwt.sign({ id: user.id, role: user.role, email: user.email, name: user.name }, process.env.JWT_SECRET || 'dev-secret-change-me', { expiresIn: '7d' });
}
function publicUser(row) {
  if (!row) return null;
  return { id: row.id, name: row.name, email: row.email, phone: row.phone, role: row.role, grade: row.grade };
}
function sendError(res, error) {
  console.error(error);
  return res.status(500).json({ error: 'حدث خطأ في الخادم' });
}
function createCode() {
  const part = () => Math.random().toString(36).slice(2, 6).toUpperCase();
  return `FH-${part()}-${part()}-${part()}`;
}

app.get('/api/health', (_req, res) => res.json({ ok: true, app: 'Mr Fares Hany Platform' }));

app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password, phone, grade } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: 'الاسم والبريد وكلمة المرور مطلوبة' });
    if (password.length < 8) return res.status(400).json({ error: 'كلمة المرور يجب أن تكون 8 أحرف على الأقل' });
    const hash = await bcrypt.hash(password, 12);
    const info = db.prepare(`INSERT INTO users(name,email,password_hash,phone,grade) VALUES(?,?,?,?,?)`).run(name.trim(), email.trim().toLowerCase(), hash, phone || '', grade || '');
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
    res.json({ user: publicUser(user), token: signToken(user) });
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return res.status(409).json({ error: 'البريد الإلكتروني مستخدم بالفعل' });
    sendError(res, e);
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get((email || '').trim().toLowerCase());
    if (!user || !(await bcrypt.compare(password || '', user.password_hash))) return res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
    res.json({ user: publicUser(user), token: signToken(user) });
  } catch (e) { sendError(res, e); }
});

app.get('/api/auth/me', requireAuth, (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  res.json({ user: publicUser(user) });
});

app.post('/api/auth/logout', (_req, res) => res.json({ ok: true }));

app.get('/api/courses', (_req, res) => {
  const courses = db.prepare(`SELECT * FROM courses WHERE status = 'published' ORDER BY id DESC`).all();
  res.json({ courses });
});

app.post('/api/courses', requireAuth, requireAdmin, (req, res) => {
  try {
    const { title, description, grade, price } = req.body;
    if (!title) return res.status(400).json({ error: 'اسم الكورس مطلوب' });
    const info = db.prepare(`INSERT INTO courses(title,description,grade,price,status) VALUES(?,?,?,?,?)`).run(title, description || '', grade || '', Number(price || 0), 'published');
    res.json({ id: info.lastInsertRowid });
  } catch (e) { sendError(res, e); }
});

app.get('/api/student/dashboard', requireAuth, (req, res) => {
  try {
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
    const enrollments = db.prepare(`SELECT e.*, c.title, c.description, c.grade, c.price FROM enrollments e JOIN courses c ON c.id=e.course_id WHERE e.user_id=? ORDER BY e.id DESC`).all(req.user.id);
    const announcements = db.prepare('SELECT * FROM announcements ORDER BY id DESC LIMIT 10').all();
    const nextLessons = db.prepare(`SELECT l.*, c.title AS course_title FROM lessons l JOIN courses c ON c.id=l.course_id JOIN enrollments e ON e.course_id=c.id WHERE e.user_id=? AND l.published=1 ORDER BY l.sort_order,l.id LIMIT 12`).all(req.user.id);
    const attempts = db.prepare(`SELECT a.*, e.title FROM attempts a JOIN exams e ON e.id=a.exam_id WHERE a.user_id=? ORDER BY a.id DESC LIMIT 10`).all(req.user.id);
    const submissions = db.prepare(`SELECT h.*, l.title AS lesson_title FROM homework_submissions h JOIN lessons l ON l.id=h.lesson_id WHERE h.user_id=? ORDER BY h.id DESC LIMIT 10`).all(req.user.id);
    res.json({ user: publicUser(user), enrollments, announcements, nextLessons, attempts, submissions });
  } catch (e) { sendError(res, e); }
});

app.get('/api/student/lessons', requireAuth, (req, res) => {
  const lessons = db.prepare(`SELECT l.*, c.title AS course_title FROM lessons l JOIN courses c ON c.id=l.course_id JOIN enrollments e ON e.course_id=c.id WHERE e.user_id=? AND l.published=1 ORDER BY c.id,l.sort_order,l.id`).all(req.user.id);
  res.json({ lessons });
});

app.get('/api/student/exams', requireAuth, (req, res) => {
  const exams = db.prepare(`SELECT x.*, c.title AS course_title FROM exams x JOIN courses c ON c.id=x.course_id JOIN enrollments e ON e.course_id=c.id WHERE e.user_id=? AND x.published=1 ORDER BY x.id DESC`).all(req.user.id);
  res.json({ exams });
});

app.get('/api/exams/:id', requireAuth, (req, res) => {
  const exam = db.prepare(`SELECT x.*, c.title AS course_title FROM exams x JOIN courses c ON c.id=x.course_id WHERE x.id=?`).get(req.params.id);
  if (!exam) return res.status(404).json({ error: 'الامتحان غير موجود' });
  const enrolled = db.prepare('SELECT 1 FROM enrollments WHERE user_id=? AND course_id=?').get(req.user.id, exam.course_id);
  if (!enrolled && req.user.role !== 'admin') return res.status(403).json({ error: 'غير مشترك في هذا الكورس' });
  const questions = db.prepare(`SELECT id,prompt,option_a,option_b,option_c,option_d,marks FROM questions WHERE exam_id=? ORDER BY id`).all(req.params.id);
  res.json({ exam, questions });
});

app.post('/api/student/exams/:id/submit', requireAuth, (req, res) => {
  try {
    const exam = db.prepare('SELECT * FROM exams WHERE id=?').get(req.params.id);
    if (!exam) return res.status(404).json({ error: 'الامتحان غير موجود' });
    const enrolled = db.prepare('SELECT 1 FROM enrollments WHERE user_id=? AND course_id=?').get(req.user.id, exam.course_id);
    if (!enrolled) return res.status(403).json({ error: 'غير مشترك في هذا الكورس' });
    const questions = db.prepare('SELECT id,correct_option,marks FROM questions WHERE exam_id=?').all(exam.id);
    const answers = req.body.answers || {};
    let score = 0, total = 0;
    for (const q of questions) { total += q.marks; if (answers[q.id] === q.correct_option) score += q.marks; }
    const info = db.prepare(`INSERT INTO attempts(exam_id,user_id,answers_json,score,total) VALUES(?,?,?,?,?)`).run(exam.id, req.user.id, JSON.stringify(answers), score, total);
    res.json({ attemptId: info.lastInsertRowid, score, total, percent: total ? Math.round(score / total * 100) : 0 });
  } catch (e) { sendError(res, e); }
});

app.post('/api/student/homework/:lessonId', requireAuth, upload.single('file'), (req, res) => {
  try {
    const lesson = db.prepare('SELECT * FROM lessons WHERE id=?').get(req.params.lessonId);
    if (!lesson) return res.status(404).json({ error: 'الدرس غير موجود' });
    const enrolled = db.prepare('SELECT 1 FROM enrollments WHERE user_id=? AND course_id=?').get(req.user.id, lesson.course_id);
    if (!enrolled) return res.status(403).json({ error: 'غير مشترك في هذا الكورس' });
    const fileUrl = req.file ? `/uploads/${req.file.filename}` : null;
    const info = db.prepare(`INSERT INTO homework_submissions(lesson_id,user_id,file_url,text_answer) VALUES(?,?,?,?)`).run(lesson.id, req.user.id, fileUrl, req.body.text_answer || '');
    res.json({ id: info.lastInsertRowid, status: 'pending' });
  } catch (e) { sendError(res, e); }
});

app.post('/api/student/redeem', requireAuth, (req, res) => {
  const { code } = req.body;
  const row = db.prepare(`SELECT * FROM subscription_codes WHERE code=? AND status='active'`).get(String(code || '').trim().toUpperCase());
  if (!row) return res.status(400).json({ error: 'كود الاشتراك غير صحيح أو مستخدم' });
  const now = new Date();
  const expires = new Date(now.getTime() + row.duration_days * 86400000).toISOString();
  const tx = db.transaction(() => {
    db.prepare(`UPDATE subscription_codes SET status='redeemed',redeemed_by=?,redeemed_at=CURRENT_TIMESTAMP WHERE id=?`).run(req.user.id,row.id);
    db.prepare(`INSERT INTO enrollments(user_id,course_id,started_at,expires_at) VALUES(?,?,?,?) ON CONFLICT(user_id,course_id) DO UPDATE SET expires_at=excluded.expires_at`).run(req.user.id,row.course_id,now.toISOString(),expires);
  });
  tx();
  const course = db.prepare('SELECT * FROM courses WHERE id=?').get(row.course_id);
  res.json({ message: 'تم تفعيل الاشتراك', course, expires_at: expires });
});

app.post('/api/admin/codes', requireAuth, requireAdmin, (req, res) => {
  try {
    const { course_id, duration_days = 30, quantity = 1 } = req.body;
    const course = db.prepare('SELECT * FROM courses WHERE id=?').get(course_id);
    if (!course) return res.status(404).json({ error: 'الكورس غير موجود' });
    const qty = Math.min(100, Math.max(1, Number(quantity)));
    const codes = [];
    const stmt = db.prepare('INSERT INTO subscription_codes(code,course_id,duration_days) VALUES(?,?,?)');
    const tx = db.transaction(() => { for (let i=0;i<qty;i++){const code=createCode();stmt.run(code,course_id,Number(duration_days));codes.push(code);} });
    tx();
    res.json({ codes });
  } catch (e) { sendError(res, e); }
});

app.get('/api/admin/stats', requireAuth, requireAdmin, (req, res) => {
  const students = db.prepare(`SELECT COUNT(*) AS c FROM users WHERE role='student'`).get().c;
  const courses = db.prepare('SELECT COUNT(*) AS c FROM courses').get().c;
  const lessons = db.prepare('SELECT COUNT(*) AS c FROM lessons').get().c;
  const activeCodes = db.prepare(`SELECT COUNT(*) AS c FROM subscription_codes WHERE status='active'`).get().c;
  const pending = db.prepare(`SELECT COUNT(*) AS c FROM homework_submissions WHERE status='pending'`).get().c;
  res.json({ students, courses, lessons, activeCodes, pending });
});

app.get('/api/admin/students', requireAuth, requireAdmin, (_req, res) => {
  const students = db.prepare(`SELECT u.id,u.name,u.email,u.phone,u.grade,u.created_at,COUNT(DISTINCT e.course_id) AS courses_count FROM users u LEFT JOIN enrollments e ON e.user_id=u.id WHERE u.role='student' GROUP BY u.id ORDER BY u.id DESC`).all();
  res.json({ students });
});

app.get('/api/admin/courses', requireAuth, requireAdmin, (_req, res) => {
  const courses = db.prepare(`SELECT c.*,COUNT(l.id) AS lessons_count FROM courses c LEFT JOIN lessons l ON l.course_id=c.id GROUP BY c.id ORDER BY c.id DESC`).all();
  res.json({ courses });
});

app.post('/api/admin/lessons', requireAuth, requireAdmin, (req, res) => {
  try {
    const { course_id, title, description, video_url, note_url, homework_text, sort_order = 0 } = req.body;
    if (!course_id || !title) return res.status(400).json({ error: 'الكورس وعنوان الدرس مطلوبان' });
    const info = db.prepare(`INSERT INTO lessons(course_id,title,description,video_url,note_url,homework_text,sort_order,published) VALUES(?,?,?,?,?,?,?,1)`).run(course_id,title,description||'',video_url||'',note_url||'',homework_text||'',Number(sort_order));
    res.json({ id: info.lastInsertRowid });
  } catch (e) { sendError(res, e); }
});

app.post('/api/admin/exams', requireAuth, requireAdmin, (req, res) => {
  try {
    const { course_id, title, duration_minutes = 30, questions = [] } = req.body;
    if (!course_id || !title || !Array.isArray(questions) || !questions.length) return res.status(400).json({ error: 'بيانات الامتحان والأسئلة مطلوبة' });
    const tx = db.transaction(() => {
      const exam = db.prepare(`INSERT INTO exams(course_id,title,duration_minutes,published) VALUES(?,?,?,1)`).run(course_id,title,Number(duration_minutes));
      const add = db.prepare(`INSERT INTO questions(exam_id,prompt,option_a,option_b,option_c,option_d,correct_option,marks) VALUES(?,?,?,?,?,?,?,?)`);
      for (const q of questions) add.run(exam.lastInsertRowid,q.prompt,q.option_a,q.option_b,q.option_c,q.option_d,q.correct_option,Number(q.marks||1));
      return exam.lastInsertRowid;
    });
    res.json({ id: tx() });
  } catch (e) { sendError(res, e); }
});

app.get('/api/admin/submissions', requireAuth, requireAdmin, (_req, res) => {
  const rows = db.prepare(`SELECT h.*,u.name AS student_name,u.email,l.title AS lesson_title,c.title AS course_title FROM homework_submissions h JOIN users u ON u.id=h.user_id JOIN lessons l ON l.id=h.lesson_id JOIN courses c ON c.id=l.course_id ORDER BY h.id DESC`).all();
  res.json({ submissions: rows });
});

app.put('/api/admin/submissions/:id/grade', requireAuth, requireAdmin, (req, res) => {
  const { grade, teacher_note = '' } = req.body;
  const n = Number(grade);
  if (Number.isNaN(n) || n < 0 || n > 100) return res.status(400).json({ error: 'الدرجة يجب أن تكون بين 0 و100' });
  db.prepare(`UPDATE homework_submissions SET status='graded',grade=?,teacher_note=?,graded_at=CURRENT_TIMESTAMP WHERE id=?`).run(n,teacher_note,req.params.id);
  res.json({ ok: true });
});

app.get('/api/admin/codes', requireAuth, requireAdmin, (_req, res) => {
  const rows = db.prepare(`SELECT s.*,c.title AS course_title,u.name AS redeemed_name FROM subscription_codes s JOIN courses c ON c.id=s.course_id LEFT JOIN users u ON u.id=s.redeemed_by ORDER BY s.id DESC LIMIT 500`).all();
  res.json({ codes: rows });
});

app.post('/api/admin/announcements', requireAuth, requireAdmin, (req, res) => {
  const { title, body } = req.body;
  if (!title || !body) return res.status(400).json({ error: 'العنوان والمحتوى مطلوبان' });
  const info = db.prepare('INSERT INTO announcements(title,body) VALUES(?,?)').run(title,body);
  res.json({ id: info.lastInsertRowid });
});

app.get('/api/translate', async (req, res) => {
  const text = String(req.query.text || '').trim();
  const direction = req.query.direction === 'en-ar' ? 'en-ar' : 'ar-en';
  if (!text) return res.json({ translation: '' });
  const local = {
    'مدرسة':'school','كتاب':'book','امتحان':'exam','نجاح':'success','طالب':'student','طالبة':'student','مدرس':'teacher','معلم':'teacher','درس':'lesson','مذاكرة':'study','مراجعة':'revision','لغة':'language','إنجليزي':'English','قواعد':'grammar','قراءة':'reading','كتابة':'writing','شكرا':'thank you','من فضلك':'please','مرحبا':'hello','توفيق':'luck',
    school:'مدرسة',book:'كتاب',exam:'امتحان',success:'نجاح',student:'طالب / طالبة',teacher:'مدرس',lesson:'درس',study:'مذاكرة',revision:'مراجعة',language:'لغة',english:'اللغة الإنجليزية',grammar:'قواعد',reading:'قراءة',writing:'كتابة','thank you':'شكرا',please:'من فضلك',hello:'مرحبا','good luck':'بالتوفيق'
  };
  if (!process.env.TRANSLATE_URL) {
    const dict = direction === 'ar-en' ? local : Object.fromEntries(Object.entries(local).filter(([k,v]) => /[\u0600-\u06FF]/.test(k)).map(([k,v]) => [k,v]));
    const key = text.toLowerCase();
    if (dict[key]) return res.json({ translation: dict[key], mode: 'dictionary' });
    return res.json({ translation: text, mode: 'dictionary', note: 'ضع TRANSLATE_URL في .env لتفعيل ترجمة الجمل الكاملة.' });
  }
  try {
    const response = await fetch(process.env.TRANSLATE_URL, {
      method: 'POST', headers: { 'Content-Type':'application/json', ...(process.env.TRANSLATE_API_KEY ? {'X-API-Key':process.env.TRANSLATE_API_KEY}:{}) },
      body: JSON.stringify({ q: text, source: direction === 'ar-en' ? 'ar' : 'en', target: direction === 'ar-en' ? 'en' : 'ar', format: 'text' })
    });
    const data = await response.json();
    res.json({ translation: data.translatedText || text, mode: 'api' });
  } catch (e) { res.status(502).json({ error: 'خدمة الترجمة غير متاحة حاليًا' }); }
});

app.get('/whatsapp', (req, res) => {
  const wa = String(process.env.WHATSAPP || '201096954340').replace(/\D/g,'');
  const message = encodeURIComponent(req.query.message || 'مرحبًا مستر فارس، أريد الاستفسار عن المنصة.');
  res.redirect(`https://wa.me/${wa}?text=${message}`);
});

app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'API route not found' });
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => console.log(`Mr Fares Hany Platform running on http://localhost:${PORT}`));
