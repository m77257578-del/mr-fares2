require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('./db');

const adminEmail = process.env.ADMIN_EMAIL || 'admin@fareshany.com';
const adminPassword = process.env.ADMIN_PASSWORD || 'ChangeMe123!';
const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(adminEmail);
if (!existing) {
  db.prepare(`INSERT INTO users(name,email,password_hash,role,phone,grade) VALUES(?,?,?,?,?,?)`)
    .run(process.env.TEACHER_NAME || 'Mr Fares Hany', adminEmail, bcrypt.hashSync(adminPassword, 12), 'admin', process.env.WHATSAPP || '201096954340', null);
}

const count = db.prepare('SELECT COUNT(*) AS c FROM courses').get().c;
if (count === 0) {
  const addCourse = db.prepare('INSERT INTO courses(title,description,grade,price,status) VALUES(?,?,?,?,?)');
  const foundation = addCourse.run('Foundation English', 'Grammar + Vocabulary + Reading', 'الصف الأول الثانوي', 100, 'published').lastInsertRowid;
  const exam = addCourse.run('Exam Skills', 'Exam practice + grammar + reading', 'الصف الثاني الثانوي', 150, 'published').lastInsertRowid;
  const final = addCourse.run('Final Revision', 'Full revision + mock exams', 'الصف الثالث الثانوي', 200, 'published').lastInsertRowid;
  const addLesson = db.prepare('INSERT INTO lessons(course_id,title,description,video_url,note_url,homework_text,sort_order,published) VALUES(?,?,?,?,?,?,?,1)');
  addLesson.run(foundation,'Parts of Speech','Introduction to nouns, verbs, adjectives.','','','حدد 10 أمثلة من الدرس.',1);
  addLesson.run(foundation,'Present Simple','Usage and common exam questions.','https://www.youtube.com/watch?v=dQw4w9WgXcQ','','حل 15 سؤال على Present Simple.',2);
  addLesson.run(exam,'Tenses Made Easy','A practical tenses review.','','','اكتب 8 جمل باستخدام الأزمنة المطلوبة.',1);
  addLesson.run(final,'Reading Skills','How to approach passages.','','','حل قطعة القراءة وأرسل إجابتك.',1);
  db.prepare('INSERT INTO announcements(title,body) VALUES(?,?)').run('مرحبًا بك في المنصة','ابدأ من Dashboard الطالب وتابع تقدمك أسبوعيًا.');
}
console.log(`Seed complete. Admin: ${adminEmail}`);
